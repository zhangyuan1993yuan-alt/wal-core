# WAL 框架项目长期记忆

## 项目状态
通用高并发 WAL（预写日志）框架 `wal-core`，2026-11-10 交付 v1.0.0-SNAPSHOT。位于 `J:/WiWork/Project/WorkBuddy/wal`。
- Java 17 / Maven / **零第三方运行时依赖** / 最终 433 用例全绿（2026-11-11：422 → 430 修 F1~F8 → 433 修组提交丢位；3 个 flaky 测试已根治）
- 用途：量化撮合系统日志底座（崩溃恢复、回放复现、备节点订阅、审计）

## 维护必读（改代码前）
- **写失败不回退 LSN**：rewind 仅恢复期可用（DefaultWal.open 内唯一调用点），运行期 rewind 会发出重复 LSN——重复比空洞危害更大，空洞由恢复期吸收
- **组提交批次失败语义**（`GroupCommitCoordinator`，改这里必读类注释）：脏位在 `drainMine` 时已从全局位图取走，因此①失败绝不能中断批次（逐个 redirty 后继续）②等待者按 `durableLsn` 真值结算（不是按"处理到第几个分区"）③0 号 flusher 每秒兜底扫描 `publishedLsn>durableLsn` 的活跃分区补脏位。破坏任一条 = 静默丢持久性或假报失败
- 帧格式唯一真源：`internal/append/FrameLayout`；CRC32C 区间 `[0,20)∪[24,frameLen)`
- 三条核心不变量：①LSN 分配在分区写锁内紧邻写帧 ②append() 路径零 new/锁/fsync/队列 ③帧完整编码后才提交写指针
- 段序列是 volatile 不可变快照（`PartitionSegments.Snapshot`），结构变更（轮转/删除/冻结）必须持 `ps.mutex`
- 保留删除走三段式（锁内定位+围栏复核+摘除，锁外 unmap+删文件）；读者有 LSN 围栏 `RetentionPin` + 段级 readerCount 双保护
- 段名 LSN 可能大于段内真实首 LSN（nameReservations 发号），恢复扫描一律以实际扫描为准
- `MappedSegmentHandle.force()` 必须 `fileChannel.force(false)`，禁用 `MappedByteBuffer.force()`；close 必须 unmap（Windows 否则删不掉文件）

## 性能口径（对用户/验收的承诺）
- `append()` p99 ≤100µs（内存）；`flushAndWait()` 默认 p99 ~1.4ms。**百万 TPS 与 100µs 持久确认单机不可兼得**
- 默认配置面向吞吐；低延迟配置 `batchIntervalMicros=20)+分区≤4+groupCommitThreads(4)`，TPS 降到 ~15 万
- 性能实测必须在 Linux NVMe 做（PERF-wal.md §2 有完整命令），Windows 只保正确性
- **埋点开销（P1-05③ <1%）本机测不了**：Windows 线程 CPU 计时粒度 15.625ms、单条 append ~7µs，比值口径依赖分母。目标机复测方法见 PERF-wal.md §6.4（CPU 时间 + 预热 + 百万条/轮 + 配对中位数）。实测固定成本约 235ns/条

## 下版本待办（优先级序）
1. Linux 目标机性能实测（填 PERF-wal.md 空表；含埋点开销 1% 的正式验收）
2. `ReplicationSink` 真实投递实现（当前插件已装配但框架零调用点，README 已如实标注，临时方案走 WalTailer 外接）
3. 万段级 RTO 并行恢复扫描
4. 在线 `verify()` API（半天量，复用恢复扫描器，只读）
5. `appendBatch` 支持混合类型与幂等键
6. 组提交退避按分区化（当前一处分区 force 失败会让同 flusher 名下全部分区退避 5s，属"有界代价"，类注释已登记）

## 详细记录
- 2026-11-10 交付全记录（含 10 个已修缺陷清单与测试时序注意事项）：见 `2026-11-10.md`
